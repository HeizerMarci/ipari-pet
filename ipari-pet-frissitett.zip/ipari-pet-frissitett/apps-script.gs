// ── Beállítások ──────────────────────────────────────────────
const FIREBASE_BASE = "https://iskola-pet-default-rtdb.europe-west1.firebasedatabase.app";
const EREDMENYEK_LAP = "Eredmények";
const PALACKOK_LAP = "palackok_live";
const VISSZAVALTAS_LAP = "tenyleges_visszavaltas";
const BETET_DIJ = 50;

/**
 * Telepíthető "On form submit" triggerhez.
 * Mindkét Google Form ugyanahhoz a spreadsheethez írhat.
 * Nem ír többé /palackok alá: a weboldal kizárólag az /allapot csomópontot olvassa.
 */
function onFormSubmit(e) {
  if (!e || !e.range) return;

  const lapNev = e.range.getSheet().getName();
  if (lapNev !== PALACKOK_LAP && lapNev !== VISSZAVALTAS_LAP) return;

  // A képletek (SUMIF, RANK stb.) frissüljenek, mielőtt kiolvassuk az eredményt.
  SpreadsheetApp.flush();
  szinkronAllapot();
}

/**
 * A teljes publikus állapot újraépítése a Google Sheetből és feltöltése Firebase-be.
 * Kézzel is futtatható, pl. első migrációkor vagy javítás után.
 */
function szinkronAllapot() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  // 1. Osztályeredmények
  const eredmenyek = ss.getSheetByName(EREDMENYEK_LAP);
  if (!eredmenyek) throw new Error(`Hiányzó munkalap: ${EREDMENYEK_LAP}`);

  const utolsoSor = eredmenyek.getLastRow();
  const osztalyok = utolsoSor >= 2
    ? eredmenyek.getRange(2, 1, utolsoSor - 1, 6).getValues()
        .filter(sor => sor[0] !== "")
        .map(sor => ({
          osztaly: sor[0],
          letszam: toNumber_(sor[1]),
          palack: toNumber_(sor[2]),
          per_fo: toNumber_(sor[3]),
          hely_kiraly: toNumber_(sor[4]),
          hely_hos: toNumber_(sor[5])
        }))
    : [];

  const osszPalack = osztalyok.reduce((sum, o) => sum + o.palack, 0);

  // 2. Tényleges visszaváltások: a tanári Form B oszlopának összege
  const visszaLap = ss.getSheetByName(VISSZAVALTAS_LAP);
  if (!visszaLap) throw new Error(`Hiányzó munkalap: ${VISSZAVALTAS_LAP}`);

  const visszaUtolsoSor = visszaLap.getLastRow();
  let osszegFt = 0;

  if (visszaUtolsoSor >= 2) {
    osszegFt = visszaLap
      .getRange(2, 2, visszaUtolsoSor - 1, 1)
      .getValues()
      .reduce((sum, [ertek]) => sum + toNumber_(ertek), 0);
  }

  const visszavaltottPalack = osszegFt / BETET_DIJ;

  // 3. Egyetlen, weboldal által olvasott Firebase-csomag
  const csomag = {
    frissitve: new Date().toISOString(),
    ossz_palack: osszPalack,
    visszavaltas: {
      osszeg_ft: osszegFt,
      palack_db: visszavaltottPalack
    },
    osztalyok: osztalyok
  };

  UrlFetchApp.fetch(FIREBASE_BASE + "/allapot.json", {
    method: "put",
    contentType: "application/json",
    payload: JSON.stringify(csomag),
    muteHttpExceptions: false
  });
}

/** Szám / Form-szöveg biztonságos konvertálása. */
function toNumber_(value) {
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;
  if (value === null || value === undefined || value === "") return 0;

  const normalized = String(value)
    .replace(/\s/g, "")
    .replace(/Ft/gi, "")
    .replace(",", ".")
    .replace(/[^0-9.-]/g, "");

  const n = Number(normalized);
  return Number.isFinite(n) ? n : 0;
}
