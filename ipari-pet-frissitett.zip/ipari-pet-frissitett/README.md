# Ipari PET – frissített adatfolyam

## Firebase
A weboldal már csak ezt olvassa:

`/allapot`

A régi `/palackok` csomópont nem szükséges.

Az `allapot` új mezője:

```json
"visszavaltas": {
  "osszeg_ft": 8500,
  "palack_db": 170
}
```

## Google Apps Script
Másold az `apps-script.gs` tartalmát a Sheethez tartozó Apps Script projektbe.

A spreadsheetben a várt munkalapnevek:
- `palackok_live` – diákok Form-válaszai
- `Eredmények` – képletekkel számolt osztályeredmények
- `tenyleges_visszavaltas` – tanári Form-válaszai; B oszlop = ténylegesen visszaváltott összeg Ft-ban

Állíts be egy telepíthető triggert:
- Function: `onFormSubmit`
- Event source: **From spreadsheet**
- Event type: **On form submit**

Ugyanez a trigger kezeli mindkét Formot, a munkalapnév alapján.

Első beüzemeléskor egyszer kézzel futtasd a `szinkronAllapot()` függvényt, hogy az új `visszavaltas` mező azonnal bekerüljön Firebase-be.
